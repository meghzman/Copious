package com.copious.training.service.user_service;

import com.copious.training.model.Request.UserRequestModel;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserServiceDeclaration {

    public List<UserRequestModel> alluser();
    public UserRequestModel singleUser(int id);
    public UserRequestModel addUser(UserRequestModel user);
    public UserRequestModel deleteUser(int id);
    public List<UserRequestModel> sortUserByName();
    public List<UserRequestModel> sortUserByAge();
    public List<UserRequestModel> voter();
   // public List<UserRequestModel> ageFilter(UserCategory category);


}
