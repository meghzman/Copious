package com.copious.training.factory;

import com.copious.training.constants.UserCategory;
import org.springframework.stereotype.Component;

@Component
public class Factory {
    public Userfilter getUserCategory(UserCategory category)
    {
        switch(category)
        {
            case Infant:return new Infant();
            case Teen:return new Teen();
            case Adult:return new Adult();
            case Senior:return new Senior();
            default:throw new IllegalStateException("Unexpected value:"+category);
        }
    }
}
