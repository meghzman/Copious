package com.copious.training.exception;

public class UserSignUpServiceException extends RuntimeException{

    public UserSignUpServiceException(String message) {
        super(message);
    }
}
