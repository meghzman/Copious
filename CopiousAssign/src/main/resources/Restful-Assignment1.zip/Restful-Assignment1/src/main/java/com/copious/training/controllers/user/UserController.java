package com.copious.training.controllers.user;

import com.copious.training.exception.ExceptionResponse;
import com.copious.training.exception.UserNotFoundException;
import com.copious.training.model.Request.UserRequestModel;
import com.copious.training.service.user_service.UserServiceImpl;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/Assignment1")
@ApiOperation(value = "Assignment1/")
@Api(tags = "User CRUD Operations")
public class UserController {

    @Autowired
    private UserServiceImpl dao;

    @Autowired
    private MessageSource messageSource;


    @ApiOperation(value = "Fetch all users", notes = "Return array list of user details")
    @GetMapping(value = "/user")
    @ApiParam(value = "param check 458")
    @ApiResponses(value = {

            @ApiResponse(code = 200, message = "Success", response = UserRequestModel.class),
            @ApiResponse(code = 400, message = "Bad Request", response = ExceptionResponse.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = ExceptionResponse.class),
            @ApiResponse(code = 403, message = "FORBIDDEN", response = ExceptionResponse.class),
            @ApiResponse(code = 404, message = "User not found", response = ExceptionResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ExceptionResponse.class),

    })
    public List<UserRequestModel> retrieveAllUser() {
        List<UserRequestModel> user = dao.alluser();
        for (UserRequestModel usercheck : user) {
            if (usercheck == null) {
                throw new UserNotFoundException("No user found");
            }
        }

        return user;
    }

    @ApiOperation(value = "Fetch single user")
    @GetMapping(value = "/user/{id}")
    public UserRequestModel retrieveUser(@PathVariable int id) {
        UserRequestModel user = dao.singleUser(id);

        if (user == null)
            throw new UserNotFoundException("id-" + id);
        return dao.singleUser(id);

    }

    @ApiOperation(value = "Add user to the list")
    @PostMapping(value = "/user")
    //response entity is used for returning correct http status code
    public ResponseEntity<Object> addUser(@Valid @RequestBody UserRequestModel user) {
        UserRequestModel savedUser = dao.addUser(user);
        //return savedUser;

        //below line is to fetch the current request that is /user and append/id, that is /user/{id}
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(savedUser.getId()).toUri();
        return ResponseEntity.created(location).build();
    }


    @ApiOperation(value = "Delete user by its id")
    @DeleteMapping(value = "/user/{id}")
    public void deleteUser(@PathVariable int id) {
        UserRequestModel user = dao.deleteUser(id);
        if (user == null) {
            throw new UserNotFoundException("id- " + id);
        }

    }

    @ApiOperation(value = "Sort user names")
    @GetMapping(value = "/user/sort/name")
    public List<UserRequestModel> sortAllUser1() {

        return dao.sortUserByName();
    }

    @ApiOperation(value = "Sort user age")
    @GetMapping(value = "/user/sort/age")
    public List<UserRequestModel> sortAllUser2() {

        return dao.sortUserByAge();
    }

    @ApiOperation(value = "Filter users who are eligible to vote", notes = "Return users with age>=18")
    @GetMapping(value = "/user/voter")
    public List<UserRequestModel> voter() {

        return dao.voter();
    }

    /*@PostMapping("/age-filter")
    public List<UserRequestModel> ageFilter(@RequestParam("ageCriteria") UserCategory age){
        return dao.ageFilter(age);
    }*/

}

