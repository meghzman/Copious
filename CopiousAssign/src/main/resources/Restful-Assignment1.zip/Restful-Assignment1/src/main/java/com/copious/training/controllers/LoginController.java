package com.copious.training.controllers;

import com.copious.training.exception.UserSignUpServiceException;
import com.copious.training.model.ErrorMessages;
import com.copious.training.model.Request.UserLoginModel;
import com.copious.training.model.Response.LoginResponse;
import com.copious.training.security.JwtTokenUtil;
import com.copious.training.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@RequestMapping
public class LoginController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private LoginService service;

    @PostMapping("/login")
    public ResponseEntity<?> createAuthenticationToken(@RequestBody UserLoginModel login) throws Exception {
        if (login.getUsername().isEmpty() || login.getPassword().isEmpty()) {
            throw new UserSignUpServiceException(ErrorMessages.MISSING_REQUIRED_FIELD.getErrorMessage());
        }
        authenticate(login.getUsername(), login.getPassword());
        final UserDetails userDetails = service.loadUserByUsername(login.getUsername());

        final String token = JwtTokenUtil.generateToken(userDetails);

        return ResponseEntity.ok(new LoginResponse(token));

    }

    private void authenticate(String username, String password) throws Exception {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        } catch (DisabledException e) {
            throw new Exception("USER_DISABLED", e);
        } catch (BadCredentialsException e) {
            throw new Exception("INVALID_CREDENTIALS", e);
        }
    }

    @GetMapping("/")
    public String home() {
        return "Hello";
    }

}
