package com.copious.training.factory;

import com.copious.training.model.Request.UserRequestModel;

import java.util.List;
import java.util.stream.Collectors;

public class Adult implements Userfilter {
    @Override
    public List<UserRequestModel> getUser(List<UserRequestModel> user) {
        return user.stream().filter(age->age.getAge()>=18&&age.getAge()<50).collect(Collectors.toList());
    }
}
