package com.copious.training.controllers.property;

import com.copious.training.service.property_service.PropertyService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@ApiOperation(value = "properties/")
@Api(tags = "System properties")
@RequestMapping(value="/properties")
public class PropertyController {

    @Autowired
    PropertyService propertyService;

    @ApiOperation(value = "Fetch system properties", notes = "It uses java property class")
    @GetMapping(value = "/system")
    public Map getSystemProperties()
    {
        return propertyService.getSystemProperties();
    }
}
