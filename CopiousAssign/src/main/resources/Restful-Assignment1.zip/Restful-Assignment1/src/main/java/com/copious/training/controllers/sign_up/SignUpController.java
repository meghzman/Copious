package com.copious.training.controllers.sign_up;

import com.copious.training.exception.UserSignUpServiceException;
import com.copious.training.model.ErrorMessages;
import com.copious.training.model.Response.UserSignUpResponseModel;
import com.copious.training.model.Request.UserSignupRequestModel;
import com.copious.training.service.signup_service.SignUpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/user")
public class SignUpController {

    @Autowired
    private SignUpService signUpService;

    @PostMapping(value = "/signup")
    public UserSignUpResponseModel signupModel(@RequestBody UserSignupRequestModel signupModel) throws Exception
    {

        if(signupModel.getUserName().isEmpty()) throw new UserSignUpServiceException(ErrorMessages.MISSING_REQUIRED_FIELD.getErrorMessage());
        return signUpService.signUp(signupModel);
    }

    @GetMapping (value = "/getall")
    public List<UserSignupRequestModel> getall()
    {
        return  signUpService.getalluser();
    }
}
