package com.copious.training.service.user_service;

import com.copious.training.factory.Factory;
import com.copious.training.model.Request.UserRequestModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Component
@Service
public class UserServiceImpl implements UserServiceDeclaration {
    @Autowired
    Factory userFactory;

    private static List<UserRequestModel> user = new ArrayList<>();

    static int count = 5;

    static {
        user.add(new UserRequestModel(1, "Meghdoot", "12343", 18, "Adult", new Date()));
        user.add(new UserRequestModel(2, "Parth", "321344", 8, "Infant", new Date()));
        user.add(new UserRequestModel(3, "Ketan", "43221", 54, "Senior_Citizen", new Date()));
        user.add(new UserRequestModel(4, "Zootopia", "12345", 17, "Teenage", new Date()));
        user.add(new UserRequestModel(5, "Jacky", "12345", 23, "Adult", new Date()));
    }


    @Override
    public List<UserRequestModel> alluser() {
        return user;
    }

    @Override
    public UserRequestModel singleUser(int id) {
        for (UserRequestModel find : user) {
            if (find.getId() == id) {
                return find;
            }
        }
        return null;
    }

    //add user
    @Override
    public UserRequestModel addUser(UserRequestModel users) {

        if (users.getId() == null) {
            users.setId(++count);
        }
        user.add(users);

        return users;
    }

    @Override
    public UserRequestModel deleteUser(int id) {
        Iterator<UserRequestModel> iterate = user.iterator();
        while (iterate.hasNext()) {
            UserRequestModel users = iterate.next();
            if (users.getId() == id) {
                iterate.remove();
                return users;
            }
        }
        return null;
    }

    //sorting using streams and comparator
    @Override
    public List<UserRequestModel> sortUserByName() {
       // List<UserRequestModel> sortList = new ArrayList<user>();
        Comparator<UserRequestModel> comp = Comparator.comparing(UserRequestModel :: getUserName);
        Collections.sort(user, comp);
        List<UserRequestModel> sortUserName = user.stream().sorted(Comparator.comparing(UserRequestModel :: getUserName)).collect(Collectors.toList());

        return sortUserName;

    }

    //sorting using Lambda and comparator
    @Override
    public List<UserRequestModel> sortUserByAge() {
        List<UserRequestModel> sortUserAge = new ArrayList<UserRequestModel>();
        //not working? Collections.copy(sortUser,user);
        sortUserAge.addAll(user);
        Comparator<UserRequestModel> byAge = (u1, u2) -> u1.getAge().compareTo(u2.getAge());
        sortUserAge.sort(byAge);
        return sortUserAge;
    }

    //filtering users who are eligible for voting
    @Override
    public List<UserRequestModel> voter() {
        List<UserRequestModel> eligibleVoter = user.stream().filter(age -> age.getAge() >= 18).collect(Collectors.toList());
        return eligibleVoter;
    }

    /*@Override
    public List<UserRequestModel> ageFilter(UserCategory category) {
        UserRequestModel user = null;
        return userFactory.getUserCategory(category).getUser(user.getAgeCriteria());
    }*/


}




