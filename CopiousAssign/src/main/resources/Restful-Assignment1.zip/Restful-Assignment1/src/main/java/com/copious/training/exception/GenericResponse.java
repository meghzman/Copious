package com.copious.training.exception;

public class GenericResponse {
}
