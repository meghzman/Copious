package com.copious.training.model;

public enum ErrorMessages {
    MISSING_REQUIRED_FIELD("One or more fields are missing"),
    RECORD_ALREADY_EXIST("Record already Exist"),
    INTERNAL_SERVER_ERROR("Internal server error"),
    NO_RECORDS_FOUND("No records forund"),
    AUTHENTICSTION_FAILED("Authentication failed"),
    COULD_NOT_DELETE_RECORD("Could not delete record"),
    ;

    private String errorMessage;

    ErrorMessages(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
