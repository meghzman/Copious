package com.copious.training.model.Response;

import java.util.Date;

public class UserSignUpResponseModel {
    private Integer userId;
    private String username;
    private Date date;
    private String encryptedPassword;

    public UserSignUpResponseModel(Integer userId, String username, Date date, String encryptedPassword) {
        this.userId = userId;
        this.username = username;
        this.date = date;
        this.encryptedPassword = encryptedPassword;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getEncryptedPassword() {
        return encryptedPassword;
    }

    public void setEncryptedPassword(String encryptedPassword) {
        this.encryptedPassword = encryptedPassword;
    }

    @Override
    public String toString() {
        return "UserSignUpResponseModel{" +
                "userId='" + userId + '\'' +
                ", username='" + username + '\'' +
                ", date=" + date +
                ", encryptedPassword='" + encryptedPassword + '\'' +
                '}';
    }
}
