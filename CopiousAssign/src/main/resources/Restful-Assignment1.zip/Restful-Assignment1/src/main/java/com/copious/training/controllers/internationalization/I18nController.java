package com.copious.training.controllers.internationalization;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Locale;


@RequestMapping(value = "/i18n")
@ApiOperation(value = "i18n/")
@Api(tags = "Internationalization")
@RestController
public class I18nController {

    @Autowired
    private MessageSource messageSource;

    @ApiOperation(value = "Wish according to country's language")
    @GetMapping(value = "/message")
    public String i18n(@RequestHeader(name = "Accept-Language",required = false) Locale locale)
    {
        return messageSource.getMessage("good.morning.message",null,locale);
    }
}
