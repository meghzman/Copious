package com.copious.training.model.Request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.Past;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

@ApiModel(description = "All User Request Fields")
public class UserRequestModel implements Serializable {

    @ApiModelProperty(notes = "Auto generated")
    private Integer id;

    @ApiModelProperty(notes = "UserName should have atleast 2 characters")
    @Size(min = 2, message = "UserName should have atleast 2 characters")
    private String userName;

    @Size(min = 4, message = "Password should have atleast 4 characters")
    private String password;


    @ApiModelProperty(notes = "categories are divided into 0-9, 9-18, 18-50, 50 and above")
    private Integer age;

    @ApiModelProperty(notes = "Infant, Teen, Adult, Senior")
    private String ageCriteria;

    @ApiModelProperty(notes = "Date must be in past")
    @Past
    private Date date;

    public UserRequestModel(Integer id, @Size(min = 2, message = "UserName should have atleast 2 characters") String userName, @Size(min = 4, message = "Password should have atleast 4 characters") String password, Integer age, String ageCriteria, @Past Date date) {
        this.id = id;
        this.userName = userName;
        this.password = password;
        this.age = age;
        this.ageCriteria = ageCriteria;
        this.date = date;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getAgeCriteria() {
        return ageCriteria;
    }

    public void setAgeCriteria(String ageCriteria) {
        this.ageCriteria = ageCriteria;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "UserRequestModel{" +
                "id=" + id +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", age=" + age +
                ", ageCriteria='" + ageCriteria + '\'' +
                ", date=" + date +
                '}';
    }
}