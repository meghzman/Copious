package com.copious.training.constants;

public enum UserCategory {
    Infant,Teen,Adult,Senior
}
