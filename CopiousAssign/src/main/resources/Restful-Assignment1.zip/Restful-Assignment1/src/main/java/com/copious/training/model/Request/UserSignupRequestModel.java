package com.copious.training.model.Request;

import java.io.Serializable;

public class UserSignupRequestModel implements Serializable {

    private Integer id;
    private String userName;
    private String password;
    private String encryptedPassword;

    public UserSignupRequestModel(Integer id, String userName, String password, String encryptedPassword) {
        this.id = id;
        this.userName = userName;
        this.password = password;
        this.encryptedPassword=encryptedPassword;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEncryptedPassword() {
        return encryptedPassword;
    }

    public void setEncryptedPassword(String encryptedPassword) {
        this.encryptedPassword = encryptedPassword;
    }

    public UserSignupRequestModel() {
    }

    @Override
    public String toString() {
        return "UserSignupModel{" +
                "id=" + id +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", encryptedPassword='" + encryptedPassword + '\'' +
                '}';
    }
}
