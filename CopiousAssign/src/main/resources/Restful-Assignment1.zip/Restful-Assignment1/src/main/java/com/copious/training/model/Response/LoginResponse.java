package com.copious.training.model.Response;

import java.io.Serializable;

public class LoginResponse implements Serializable {
    private final String jwttoken;

    public LoginResponse(String jwttoken) {
        this.jwttoken = jwttoken;
    }

    public String getJwttoken() {
        return jwttoken;
    }
}
