package com.copious.training.service.signup_service;

import com.copious.training.controllers.LoginController;
import com.copious.training.exception.UserSignUpServiceException;
import com.copious.training.model.ErrorMessages;
import com.copious.training.model.Request.UserLoginModel;
import com.copious.training.model.Response.UserSignUpResponseModel;
import com.copious.training.model.Request.UserSignupRequestModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class SignUpService {

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
    static List<UserSignupRequestModel> usersignup = new ArrayList<>();
    static int count = 1;

    static {
        usersignup.add(new UserSignupRequestModel(1, "meghdoot", "ojha", "$2a$10$5GBIGLq8C8iuVIKqWvLPcuOKvm3xFc3QMBzawLVmbpMr4NtEP89vK"));

    }


    public UserSignUpResponseModel signUp(UserSignupRequestModel user) {
        for (UserSignupRequestModel find : usersignup) {
            if (find.getUserName().equals(user.getUserName())) {
                System.out.println("User already exist");
                throw new RuntimeException("Username already exist");
            }
        }
        if (user.getId() == null) {
            user.setId(++count);
        }
        user.setEncryptedPassword(bCryptPasswordEncoder.encode(user.getPassword()));
        usersignup.add(user);
        UserSignUpResponseModel res = new UserSignUpResponseModel(user.getId(), user.getUserName(), new Date(), user.getEncryptedPassword());
        return res;
    }

    public List<UserSignupRequestModel> getalluser() {
        return usersignup;
    }

    public UserSignUpResponseModel getUser(String username) {
        if (username == null) {
            throw new UsernameNotFoundException(username);
        }
        for (UserSignupRequestModel find : usersignup) {
            if (find.getUserName().equals(username)) {
                System.out.println("User matched" + find.getUserName());
                UserSignUpResponseModel res = new UserSignUpResponseModel(find.getId(), find.getUserName(), new Date(), "Password is hidden");
                return res;
            }

        }
        return null;
    }


    public String loadUser(String username, String password) throws UsernameNotFoundException {

        for (UserSignupRequestModel find : usersignup) {

            if (find.getUserName().equals(username) && find.getEncryptedPassword().equals(password)) {

                System.out.println("User and password matched for the user - " + find.getUserName());

                return "Login Success";
                //return new User(find.getUserName(), find.getEncryptedPassword(), new ArrayList<>());
            }
                else throw new UserSignUpServiceException(ErrorMessages.AUTHENTICSTION_FAILED.getErrorMessage());
        }
        return null;
    }
}
