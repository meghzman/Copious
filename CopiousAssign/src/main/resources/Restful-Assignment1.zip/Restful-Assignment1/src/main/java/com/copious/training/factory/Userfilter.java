package com.copious.training.factory;

import com.copious.training.model.Request.UserRequestModel;

import java.util.List;

public interface Userfilter {
    List<UserRequestModel> getUser(List<UserRequestModel> user);
}
