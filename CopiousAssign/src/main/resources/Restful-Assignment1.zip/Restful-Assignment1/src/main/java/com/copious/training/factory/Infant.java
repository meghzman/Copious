package com.copious.training.factory;

import com.copious.training.model.Request.UserRequestModel;

import java.util.List;
import java.util.stream.Collectors;

public class Infant implements Userfilter {

    @Override
    public List<UserRequestModel> getUser(List<UserRequestModel> user) {
        return user.stream().filter(age -> age.getAge() < 10).collect(Collectors.toList());
    }
}
